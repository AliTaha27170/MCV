# Sidebar: Simple class wrote in TypeScript and jQuery

This is a simple class that creates left/right sidebars with onclick event. Can be used for navigation, extra information or any other content on your website. 
